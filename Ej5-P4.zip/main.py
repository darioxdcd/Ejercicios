suma = 0
print ('Hasta que numero?')
B=int(input())
for i in range (1,(B + 1)**5):
  suma = suma + i
print(suma)